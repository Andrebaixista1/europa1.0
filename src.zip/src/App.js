// src/App.js
import React from "react";
import Login from "./components/Login";
import "bootstrap/dist/css/bootstrap.min.css";
import "@fortawesome/fontawesome-free/css/all.min.css";

function App() {
  return <Login />;
}

export default App;
